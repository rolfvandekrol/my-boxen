This directory is managed by the Boxen PHP module. Other files within this folder may be purged when boxen runs to ensure that the configs are clean and no files remain lying around - you have been warned!

http://christian.hofstaedtler.name/blog/2008/11/puppet-managing-directories-recursively.html